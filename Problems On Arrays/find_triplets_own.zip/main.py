def SortedTriplets(nums):
    if len(nums) < 3:
        return False 
    
    a = 0  
    j = 1 
    k = 2 
    
    while k != len(nums):
        if nums[a] > nums[j]:
            j = j+1 
            k = k+1 
        elif nums[j] < nums[k]:
            return nums[a],nums[j],nums[k]
        
        else:
            
            k = k+1
    return False

print(SortedTriplets([4,3,7,6,1,9]))
#Problem Practice Link: https://leetcode.com/problems/increasing-triplet-subsequence/
# Here my approach is to use 3 pointers and checked their values
                


