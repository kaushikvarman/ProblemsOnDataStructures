def Evendigit(nums):
    count = 0
    for i in range(len(nums)):
        if len(str(nums[i])) % 2 == 0:
            count += 1 
            
    return count
        
print(Evendigit([555,901,4482,1771]))

#Problem Practice Link: https://leetcode.com/problems/find-numbers-with-even-number-of-digits/
