def DutchNationalFlag(nums):
    c0 = c1 = c2 = 0
    for i in nums:
        if i == 0:
            c0 += 1 
        elif i == 1:
            c1 += 1 
        else:
            c2 += 1 
    nums[:c2] = [0] * c0
    nums[c0:c0+c1] = [1] * c1
    nums[c0+c1:] = [2]*c2
    return nums
        
        

print(DutchNationalFlag([1,0,0,2,2,1]))
# in this approach we traversed the nums and counted how many 0'2,1's,2's are there..
# and later we replaced the values of nums with the count of c0's,c1's,c2's 
# link = https://leetcode.com/problems/sort-colors/