def findUnsortedSubarray(nums):
    start = len(nums)
    end = 0
    nums2 = sorted(nums)
    for i in range(len(nums)):
        if nums[i] != nums2[i]:
            start = min(start,i)
            end = max(end,i)
    if end-1 < 0:
        return 0
    else:
        return end-start+1

print(findUnsortedSubarray([2,6,4,8,10,9,15]))


#In the second approach ..we have duplicated our initial array and sorted it
#And we have found the indices where the values are not equal and retrived their index values
#and stored in start and end 
#Edge case : [1,2,3,4] as this is already sorted ..we will not find any unsorted findUnsortedSubarray
#so we used "if end-1 < 0: return 0"
#time complexity is O(nlogn) and space complexity O(n)