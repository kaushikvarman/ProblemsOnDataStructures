def binarysearch(row):
    start = 0
    end = len(row)
    while start<end:
        mid = (start+end)//2
        
        if row[mid] == 1:
            start =mid + 1 
        else:
            end = mid 
    return start
            

def KWeakestRows(Nums,k):
    
    counts = [(binarysearch(row),i)  for i,row in enumerate(Nums)]
    counts.sort()
    
    return [ counts[i][1] for i in range(k)]

print(KWeakestRows([[1,1,0,0],[1,1,1,1],[1,0,0,0],[1,1,1,0]],2))

#problem Practice link: https://leetcode.com/problems/the-k-weakest-rows-in-a-matrix/

#approach ..here the approach is simple
#As the matrix is sorted...we have applied binary search on each row 
#and found the index of 1's..when we found the index of 1..we assign start =mid+1 
#And the index of start gives us the number of 1's in the array 
#At last we return the indecies of the row which are wealest

#Another approach to solve for reducing space complexity is by using max heap
#First we will calculate no's of ones in each row
#code : https://docs.google.com/document/d/1ezrslzTfO3FqptnKOgZPvBCCi2frhDrCezmxhhrbQYI/edit?usp=sharing

    
