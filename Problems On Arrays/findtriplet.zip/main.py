def findtriplet(arr):
    if len(arr) < 3:
        return False 
    
    mid = -1 
    low = -1 
    min_index = 0 
    for i in range(len(arr)):
        if(arr[i]<=arr[min_index]):
            min_index = i 
        elif mid == -1:
            low = min_index
            mid = i 
        elif arr[i] <= arr[mid]