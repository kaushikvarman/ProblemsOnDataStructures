def FindTriplet(nums):
    first = second = float('inf')
    for n in nums:
        if n <= first:
            first = n
        elif n <= second:
            second = n
        else:
            return True
    return False
    
# here the approach is simple ..
# we have initiated first and second with max_value
# for n in nums if n is less than first ..we assign first
# Similarly if n is less than second ..we assign n to second 
# if the 3rd value is greater than first and second...we found the triplet