def FindLeaders(nums):
    max1 = 0
    Leaders = []
    for i in range(len(nums)-1,-1,-1):
        if nums[i] > max1:
            max1 = nums[i]
            Leaders.append(max1)
        else:
            pass 
    
    return Leaders
            
print(FindLeaders([8,4,2,3,1,5,4,2]))

#just traverse the list from right to left
#https://practice.geeksforgeeks.org/problems/leaders-in-an-array/

        