def DutchNationalFlag(arr):
    low = mov = 0 
    high = len(arr)-1
    
    while mov <= high:
        if arr[mov] == 0:
            arr[mov],arr[low] = arr[low],arr[mov]
            low += 1 
            mov += 1 
        
        elif arr[mov] == 1:
            mov += 1 
        
        else:
            arr[high],arr[mov] = arr[mov],arr[high]
            high -= 1 
    return arr 

print(DutchNationalFlag([0,1,1,2,0,2]))

#here we are just rearranging the values ..like if we value if 0(we move it to left)
#if value is 1 we just increment
#if value is 2 we try to bring it to right
#here mov is used to move thru indices 
#at the end ..low will be pointing to index of first 1 and high will be 
#pointing to index of first 2