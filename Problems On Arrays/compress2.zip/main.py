def compress(s):
    s += '!'
    result = []
    i = 0
    j = 0 
    while(j<len(s)):
        if (s[i]==s[j]):
            j += 1 
        else:
            num = j-i #here we are using string index to count the number of occurance  
            
            if num>1:
                result.append(str(num)+s[i])
            else:
                result.append(s[i])
            i = j
        

    return ''.join(result)
    
print(compress('aaavvcc'))

