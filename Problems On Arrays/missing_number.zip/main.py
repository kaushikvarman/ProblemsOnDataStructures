#find the missing number






#approach 1 is a brute force and has O(n^2)
a = [1,2,4,3,6,7,9,8,10]
for i in range(1,10):
    if i in a:
        pass
    else:
        print(i)
    
#approach 2 using sum of n numbers has O(n) and has a drawback
#the drawback is What is n has the value of max_int..then we cannot calculte sum
n = int(input())
sum1 = n*(n+1)/2
sum2 = 0
print(sum1)
for i in range(len(a)):
    sum2 += a[i]

diff = sum1-sum2
print(diff)


#approach 3 using XOR operation, solves in O(n)
#As XOR has a property that if 2 bits are same 
# it returns 0 and returns the other bit if one
# bit is zero,So when we xor both xor of(1 to n) 
# and arr[] We were able to find the missing element
# as expect one element all the element would be same
def missing_number(arr,n):
    x1 , x2 = arr[0], 1
    for i in range(1,n):
        x1 ^= arr[i]
    for i in range(2,n+2):
        x2 ^= i 
    return x1^x2 
arr = [1,2,4,3,6,7,9,8,10]
print(missing_number(arr,len(arr)))
    
    
    
