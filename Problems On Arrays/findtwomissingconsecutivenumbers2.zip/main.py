def findMissingConsecutive(arr,n):
    xor = 0 
    for i in range(0,n):
        xor ^= arr[i]
    for i in range(0,n+2):
        xor ^= i
        
    set_no = (xor) & ~(xor-1)
    
    x = 0 
    y = 0 
    for i in range(n):
        if arr[i] & set_no:
            x ^= arr[i]
        else:
            y ^= arr[i]
    
    for i range(n+2):
        if i & set_no:
            x ^= i 
        else:
            y ^= i 
    return x,y
    
# explanation for set_no
# If input array was composed of natural numbers, xor would be positive xor & ~xor is zero 
# (Definition as all bits are inverted) On subtracting 1 from xor,

# If right most bit was zero it would be set to 1 and exit
# Reset rightmost bit to zero and try to add 1 to next bit (step 1)
# In short all rightmost bits that were 1 would become zero(inverted back similar to xor) 
# and first (rightmost) zero bit would become 1(same as xor). Now on anding,
# all bits left of this newly set 1 bit are different in xor and ~(xor-1), 
# so they would generate 0, all bits right to this newly set 1 bit are zero in both xor and ~(xor-1)
# so they would generate 0. Only bit at bit position where 1 was newly set in ~(xor-1) is 1 in both case, 
# so only this bit would be set in expression xor & ~(xor-1)