def subsetSum(nums):
    sum1 = 0 
    for i in nums:
        sum1 = sum1 + i 
    sum2 = 0
    for j in range(len(nums)-1,-1,-1):
        sum2 = sum2 + nums[j]
        sum1 = sum1 - nums[j]
        if sum1==sum2:
            return True 
    
    return False
    
print(subsetSum([1,5,11,5]))
#Problem Practice Link: https://leetcode.com/problems/partition-equal-subset-sum/
#In this approach first we have calculted sum of array in the first iteration..
#then we calculted sum2 in 2nd iteration and checked if sum1==sum2(refer code)
#print(subsetSum([1,5,11,5])) But for this case our approach is not working..we have to 
#modify this..will do that in next approach