def subsetsum(nums):
    left_sum = leftsum + nums[0]
    right_sum = right_sum + nums[len(nums)-1]
    i = 1
    j = len(nums)-2 
    while(i<j):
        left_sum += nums[i]
        right_sum += nums[j]
        
        if left_sum == right_sum:
            return True
    return False

print(subsetsum([1,2,3,4]))