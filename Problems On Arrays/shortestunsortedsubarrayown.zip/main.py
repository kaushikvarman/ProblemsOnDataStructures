def SS(a):
    i = len(a)
    j = 0
    
    for k in range(len(a)-1):
        if a[k] < a[k+1]:
            pass 
        else:
            i = min(i,k)
    
    for k in range(len(a)-1,0,-1):
        if a[k] > a[k-1]:
            pass 
        else:
            j = max(j,k)
            
    if j-1>0:
        return j-i+1
    else:
        return 0
print(SS([2,6,4,8,10,9,15]))
            