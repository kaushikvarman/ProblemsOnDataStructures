def pair_product(numbers,product):
    hashmap = {}
    for index,i in enumerate(numbers):
        complement = product / i 
        if complement in hashmap:
            return (hashmap[complement],index)
        hashmap[i] = index 
        
    
print(pair_product([4,7,9,2,5,1],35))