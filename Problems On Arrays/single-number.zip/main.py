#Single Number 
#approach 1 would be to use hashtable and loop through each element and store it as key-value pair
#where key is number and value is its count

# def create_dictionary(numbers):
#     count_dict = {}
#     for num in numbers:
#         if num in count_dict:
#             count_dict[num] += 1
#         else:
#             count_dict[num] = 1
#     return count_dict

# # Example usage
# numbers = [1, 2, 3, 2, 1, 3, 4, 2, 1]
# result = create_dictionary(numbers)
# print(result)

#approach 2
#here we are using xor ..we can get intuition from sum 1 in document this the best approach 
def getOddOccurence(arr):
    res = 0 
    for i in arr:
        res = res^i 
    return res 
    
if __name__=='__main__':
    arr=[2, 3, 5, 4, 5, 2, 4, 3, 5, 2, 4, 4, 2]
    
    print(getOddOccurence(arr))
