def rotate(A):
    n = len(A)
    row_length = len(A[0])
    for i in range(n):
        for j in range(i):
            A[i][j],A[j][i] = A[j][i],A[i][j]
    
    i = 0
    j = len(A)-1 
    while(i!=j):
        temp = A[i]
        A[i] = A[j]
        A[j] = temp 
        i += 1 
        j -= 1 
    
    return A 
print(rotate([[1,2,3],[4,5,6],[7,8,9]]))

#approach
#we are rotating our array to 90
#Problem Practice Link: https://leetcode.com/problems/rotate-image/
#The approach is first we will transponse our matrix
#then we swap first rows with last rows..except the middle one 
#but in leetcode we have to swap columns..but in here I swapped rows