def EvenNumberDigit(nums):
    
    count = 0 
    divisor = 10
    for i in range(len(nums)):
        if nums[i] >= 10:
            quo = nums[i]//divisor
            if quo%2 == 0:
                count += 1 
    
    return count

print(EvenNumberDigit([12,345,2,6,]))

#Problem Practice Link: https://leetcode.com/problems/find-numbers-with-even-number-of-digits/
            