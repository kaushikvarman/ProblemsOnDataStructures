def pair_sum(nums,sum1):
    numbers = {} 
    for index,i in enumerate(nums):
        complement = sum1 - i
        
        if complement in numbers:
            return (numbers[complement],index)
        numbers[i] = index
            
#nums = [1,5,4,3,2]
print(pair_sum([1,5,3,2],8))