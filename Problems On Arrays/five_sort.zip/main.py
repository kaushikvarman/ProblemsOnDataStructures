def five_sort(a):
    i = 0 
    j = len(a)-1 
    while (i <=  j):
        if a[j] == 5:
            j = j-1 
        if a[i] != 5:
            i = i+1 
        else:
            temp = a[j]
            a[j] = a[i]
            a[i] = temp 
    
    return a 
print(five_sort([1,2,5,3,5,5]))