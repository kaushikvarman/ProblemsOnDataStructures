def findUnsortedSubarray(nums):
    
    stack = []
    start,end = len(nums),0
    
    #traverse array from left to right
    for i in range(len(nums)):
        
        if stack and nums[stack[-1]] > nums[i]:
            start = min(stack.pop(),start)
        stack.append(i)
        
    stack = []
    
    for j in range(len(nums)-1,-1,-1):
        if stack and nums[stack[-1]] < nums[j]:
            end = max(stack.pop(),end)
        stack.append(j)
    
    if end-start>0:
        return end-start+1
    else:
        return 0

print(findUnsortedSubarray([2,6,4,8,10,9,15]))

#here we have used stack
#first we will traverse the list from left to right and if stack[-1] > nums[i] ..we will
#pop it and store it in start 
#similarly we will traverse the list from right to left and stack[-1] < nums[j]
# we will store that index value in end 