
    def merge(self,arr,left,right):
        
        i ,j ,k = 0, 0, 0
        while i<len(left) and j<len(right):
            if left[i] < right[j]:
                arr[k] = left[i]
                i = i+1 
            else:
                self.global_inv += 1 
                arr[k] = right[j]
                j = j +1 
            k += 1
        
        while i<len(left):
            arr[k] = left[i]
            i += 1 
            k += 1 
        while j<len(right):
            arr[k] = right[j]
            j += 1 
            k += 1
                
        return global_inv
    
    def mergesort(self,arr):
        global_inv = 0
        if len(arr)>1:
            mid = len(arr)//2
            left = arr[:mid]
            right = arr[mid:]
            mergesort(left)
            mergesort(right)
            merge(arr,left,right)
        
        return global_inv
    
    # def 
    # self.local_inv = 0 
        
    #     for i in range(len(arr)-1):
    #         if a[i] > a[i+1]:
    #             self.local_inv += 1 
        
print(mergesort(['1,2,6,4,5']))
    
