def setZeroes(nums):
    
    m = len(nums) #num of rows 
    n = len(nums[0]) # nums of col 
    
    rows = set()
    columns = set()
    
    for i in range(m):
        for j in range(n):
            if nums[i][j] == 0:
                rows.add(i)
                columns.add(j)
    
    
    for i in range(m):
        for j in range(n):
            if i in rows or j in columns:
                nums[i][j] = 0
    
    return nums

#approach 
#here first we iterate every element of matrix and find the location of
#zero ...
#after finding location of zero..we add its row and column to our set 
#row and column 
#We iterate our matrix again and if our row or column is in set..
#then we assign their value to zero 
#time complexity O(n^2).. Space O(n)
#Problem Practice Link: https://leetcode.com/problems/set-matrix-zeroes/
