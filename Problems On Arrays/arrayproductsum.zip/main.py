def ArrayProductSum(nums):
    output = [0] * len(nums)
    left = 1 
    right = 1 
    for i in range(len(nums)):
        output[i] = left 
        left *= nums[i]
    for j in range(len(nums)-1,-1,-1):
        output[j] *= right 
        right *= nums[j]
    return output

print(ArrayProductSum([10,3,5,6,2]))

#here in this approach we will take an output array of len nums
#First we will find product of left elements for each index value  ...in the first iteration
#In 2nd iteration we will run loop from right to left ..while iterating we will multiply woth right
#refer code for intuition