def KWeakestRows(Nums,k):
    
    counts = [ (sum(row),i) for i,row in enumerate(Nums)]
    counts.sort()
    return [counts[i] for i in range(k)]

print(KWeakestRows([[1,1,1,0],[1,0,0,0],[1,1,0,0],[1,1,1,1],[0,0,0,0]],2))
    
#Problem Practice link: https://leetcode.com/problems/the-k-weakest-rows-in-a-matrix/

#Here the approach is simple
#In our matrix we have only 1's and 0's ...so each row contains 0's and 1's
#The rows which have less number of 1's is weakest 
#As we have only 1's and 0's we are calculating sum of each row to know its weakness
#We used enumerate..here row in for loop represents a row in matrix
#and i represents its index
#In the end we return count till range k
#the time complexity is O(m(n+log m))