def SortedRotated(a,sum1):
    n = len(a)
    l = None
    r = None 
    for i in range(n-2):
        if a[i] > a[i+1]:
            l = (i+1)%n
            r = i
            break 
    while(l!=r):
        if a[l] + a[r] == sum1:
            return True
        if a[l] + a[r] < sum1:
            l = (l+1)%n
        else:
            r = (n+r-1)%n 
    
    return False
print(SortedRotated([11,15,26,38,9,10],33))

# link : https://leetcode.com/problems/search-in-rotated-sorted-array/
# Here we used two pointers such a way that it rotates around our list which is "a" here 
# for left pointer after reaching n to be pointed back to index 0..we used l = (l+1)%n
# similarly for right pointer as it reaches 0..then it has to be pointer to n..so we used r = (n+r-1)%n
        
        
    