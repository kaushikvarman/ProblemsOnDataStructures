def setZeroes(matrix):
    
    for_row,for_col = False,False 
    m = len(matrix)
    n = len(matrix[0])
    
    for i in range(m):
        for j in range(n):
            if i == 0 and matrix[i][j] == 0:
                for_row = True 
            if j == 0 and matrix[i][j] == 0:
                for_col = True 
            if matrix[i][j] == 0:
                matrix[0][j] = 0 
                matrix[i][0] = 0 
    
    for i in range(1,m):
        for j in range(1,n):
            if matrix[i][0] == 0 or matrix[0][j] == 0:
                matrix[i][j] = 0 
    
    if for_row:
        for i in range(n):
            matrix[0][i] = 0 
    
    if for_col:
        for i in range(m):
            matrix[i][0] = 0 
    
    return matrix
print(setZeroes([[1,1,1],[1,0,1],[1,1,1]]))

#Problem Practice Link: https://leetcode.com/problems/set-matrix-zeroes/

#approach
#initially we take 2 boolean variables 
#Here in first traversal...we see if there any 0's in first row and
#first col...if it is there we set its value as true 
#also if any element in the matrix is zero...
#then we set its corresponding first row and first col values as 0(from lines 13 -15)

#later in 2nd traversal(from 1 to m and n) if any 0th row of matrix or 0th column of matrix is 0 
#Then we will assign matrix[i][j] = 0

#if for_row is true(meaning there is 0 in zeroth row) then we set entire row to 0 
#similarly to for_col too