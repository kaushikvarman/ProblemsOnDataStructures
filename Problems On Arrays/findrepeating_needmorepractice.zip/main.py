def findRepeatingElement(arr):
    x = 0 
    y = 0 
    xor = arr[0]
    for i in range(1,n):
        xor ^= arr[i] 
    for i in range(1,n-1):
        xor ^= i 
        
    set_no = xor & ~(xor-1)
    
    for i in range(n):
        if arr[i] & set_no: 
            x^=arr[i]
        else:
            y^arr[i]
    
    for i in range(1,n-1):
        if i & set_no: 
            x ^= i 
        else:
            y ^= i 
    
    return x,y  
if __name__=='__main__':
    arr=[4, 2, 4, 5, 3, 3, 1]
    x,y=findRepeating(arr,len(arr))
    print(x,y)
    