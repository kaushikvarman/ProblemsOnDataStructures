def mergeIntervals(intervals):
    intervals.sort(key=lambda x:x[0])
    
    stack = []
    
    n = len(intervals) 
    stack.append(intervals[0])
    
    for i in range(1,n):
        top = stack[-1]
        
        if(top[1] <= intervals[i][0]):
            stack.append(intervals[i])
        elif (top[1] < intervals[i][1]):
            top[1] = intervals[i][1]
            stack.pop()
            stack.append(top)
    
    for i in range(len(stack)):
        top = stack[-1]
        print(top[0],top[1])
        stack.pop()
if __name__=='__main__':
    l=[[6, 8], [1, 9], [2, 4], [4, 7]]
    mergeIntervals(l)

#approach
#TO solve the problem in O(nlogn) we used sorting and stack
#First we have to sort the intetvals based on their first value which is [0]
#Then we will insert our first set into the stack
#now for the next set...we compare it with the set which is in the stack "(top=stack[-1])"
#if 2nd ele of top is <= first elemnet of the set 
#then we will just append the new set into the stack
#elif we check second ele of top < secong of new set ...then we to merge them
#so we change the value of top[1]=intervals[i][1] ..then we pop cuurent set and append the
#new set...at last we return stack element..which r our merged intervals