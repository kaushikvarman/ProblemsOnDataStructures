def intersection(num1,num2):
    set1 = set(num1) #we are using set because it takes O(1) for inserting,searching
    result = []
    for i in num2:
        if i in set1:
            result.append(i)
    return result 
    
print(intersection([1,2,3],[1,2]))