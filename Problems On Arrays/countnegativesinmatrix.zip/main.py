def CountNegativesInMatrix(matrix):
    
    rows = len(matrix)
    cols = len(matrix[0])
    
    i,j = rows-1,0
    count = 0
    while i>=0 and j<cols:
        if matrix[i][j] < 0:
            count += cols-j
            i -= 1 
        else:
            j += 1 
    
    return count

#Problem Practice Link: https://leetcode.com/problems/set-matrix-zeroes/

#approach
#the approach is pretty simple
#Imagine a 4*4 matrix in ur head ...
#in the matrix we iterate from last row and first column(4th row, 1st col)
#if element in (4,1) is less than 0..them remaining ele of that row will be less than 0 too
#so we increment count += cols-j...and we move on next row(i-1) which is 3rd row 
#and if the element is not zero...we check reamining element of that row(j += 1)
#In the end we return count


#good to remember:
#if we are given a non sorted array..then entire elements of both 
#rows and columns will follow that order


    
                 
                