def gameoflife(nums):
    
    rows = len(nums)
    cols = len(nums[0])
    
    neighbors = [(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1),(0,0),(1,1)] #taking all the 8 sides of matrix
    copy_nums = [[ board[row][col] for col in range(cols)] for row in range(rows)]
    
    for row in range(rows):
        for col in range(cols):
            live_neighbors = 0 
            for neighbor in neighbors:
                r = row + neighbor[0]
                c = col + neighbor[1] 
                if (r<rows and r>=0) and (c<cols and c>=0) and copy_nums[r][c] == 1:
                    live_neighbors += 1
            if copy_board[row][col] == 1 and (live_neighbors < 2 or live_neighbors > 3):
                board[row][col] = 0 
            
            if copy_board[row][col] == 0 and (live_neighbors == 3):
                board[row][col] = 1 
                
#explanation:

#Problem Practice link: https://leetcode.com/problems/game-of-life/

# here first we will take a copy of given board 
# next we declare all the possible neighbors ..refer line6 
# now we iterate thru our rows and cols and first we will calculate live neighbors for each row and col 
# line 15 is an edge case to not cross the size of the board ..and here now we get live_neighbors
# Now we will check with the cases given in question