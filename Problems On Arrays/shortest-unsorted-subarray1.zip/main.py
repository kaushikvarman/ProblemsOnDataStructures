def findUnsortedSubarray(nums):
    start = len(nums)
    end = 0 
    for i in range(len(nums)-1):
        for j in range(i+1,len(nums)):
            if nums[i] > nums[j]:
                start = min(start,i)
                end = max(end,j)
    if end-1 < 0:
        return 0
    else:
        return end-start+1
print(findUnsortedSubarray([2,6,4,8,10,9,15]))

#here we have used the idea of selection sort(for every iteration we find the min value
# and swap it with its indicies)
# here we have used start and end to find the indicies of the unsorted subarray
#the time complexity of this approach is O(n^2) and in leetcode we will get time limit exceeded