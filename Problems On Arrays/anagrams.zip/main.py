#anagrams 

def anagrams(s1,s2):
    return char_count(s1) == char_count(s2)

def char_count(s):
    count = {} 
    
    for char in s:
        if char in count:
            count[char] += 1 
        else:
            count[char] = 1 
    
    return count 

# print(char_count('abcdd')) returns a dictionary with char count 
print(anagrams('cats','tacs'))

#2nd approach would be using inbuilt Counter which performs char count function
#"from collections import Counter"