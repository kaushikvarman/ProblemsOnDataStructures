def Threesum(nums):
    nums.sort()
    result = []
    for i in range(len(nums)-1):
        j = i+1 
        k = len(nums)-1 
        
        while(j<k):
            
            sum1 = nums[i] + nums[j] +nums[k]
            if sum1 == 0:
                result.append([nums[i],nums[j],nums[k]])
                j = j+1 
                k = k-1 
            elif sum1 < 0:
                j = j + 1 
            else:
                k = k - 1 
    
    return set([tuple(x) for x in result])
    

print(Threesum([-1,0,1,2,-1,-4]))

#approach
#First we sort our list and then we traverse the loop and 
#initialise 2 pointer j and k ..if sum of i,j,k are zero then 
#they have to be appended to the resultand list and we move j = j+1\
#and k=k-1(backward) to see if there are any more sets
#if sum < 0...we move j(forward)..else we move k(backward) 