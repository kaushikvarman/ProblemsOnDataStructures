def intersection(a,b):
    items_set = set(a)
    return [ ele for ele in b if ele in items_set ]
    
print(intersection([1,2,3,4],[2,4]))