#Find two Missing numbers
import math

def find_two_missing_nums(input_list, n):

  print(input_list)
  
  missing_nums_sum = (n*(n+1)/2) - sum(input_list) #O(n)
  
  if missing_nums_sum%2 != 0: #If the sum if odd - then average becomes float
      missing_nums_avg = int(math.ceil((missing_nums_sum/2)-1)) 
  else: #If the sum is even - then average stays as an integer
      missing_nums_avg = missing_nums_sum/2
      
  sum_till_avg = ( (missing_nums_avg) * (missing_nums_avg+1)/2 )

  sum_till_avg_inp = 0
  for ele in input_list: #O(n)
    if ele <= missing_nums_avg:
      sum_till_avg_inp += ele

  n1 = int(sum_till_avg -  sum_till_avg_inp)
  n2 = int(missing_nums_sum - n1)

  print(n1, n2)
nums = [1,2,3,5,7]
n = len(nums) + 2
find_two_missing_nums(nums,n)

#In this approach first we find sum of nums+2 elements
#Next we will find Given list (nums( ...sum
#Now we will find diff bw sum of nums+2 elements and  sum of nums(Missing sum)
# we will find the avg of missing sum
#Now we will find sum of nums+2 elements till avg (sum till avg)
#next we will find sum of input list where arr[i] <= avg 
#if we subrract them ..we will get our first number 
#from first number we will get our 2nd number 