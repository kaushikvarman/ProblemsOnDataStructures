def most_frequest_chat(s):
    count = {}
    for char in s:
        if char not in count:
            count[char] = 0 
        count[char] += 1 
        
    freq = None 
    for char in s:
        if freq is None or count[char] > count[freq]:
            freq = char 
            
    return char