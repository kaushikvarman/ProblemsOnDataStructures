def FindMissingPositive(nums):
    
    result = 1 
    nums.sort()
    for i in range(len(nums)):
        if nums[i] == result:
            result += 1 
    return result 
    
#Explanation with examples given in leetcode 
#example 1: [7,8,9,10,11]
#here initially we declare result = 1 ...
#and if any element in the list matches with result we increment it by 1 
#so for example 1 ..the output is 1 ..here we compare it with every element in list
#at last we return 1..as it is a missing positive number 

#example 2 : [-2,-1,0,2,5]
#here also same thing..we can see 1 is missing 

#example 3: [0,1,2]
#in here nums[i] == result..then we increment result..and result becomes 2
#In next iteration nums[i] == 2 and return is also 2..so we increment return to 3
#and in end return 3
#in next