def compress(s):
    result = []
    i = 0 
    j = 0 
    while j < len(s):
        if s[j] == s[i]:
            j = j+1 
        else:
            nums = len(s[i:j])
            if nums > 1:
                result.append(str(nums)+s[i])
            else:
                result.append(s[i])
            i = j
            
        if j == len(s):
            nums = len(s[i:j])
            if nums > 1:
                result.append(str(nums)+s[i])
            else:
                result.append(s[i])
            
            
            
    return ''.join(result)
print(compress('cccaaa'))
print(compress('ccaaatsss'))
print(compress('ssssbbz'))

    